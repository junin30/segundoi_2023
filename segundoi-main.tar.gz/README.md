# primeirob_3t

Vinícius Yudi Kondo Nº31 2ºI
Ian Pedro Tiado Ferreira Nº17 2ºI
