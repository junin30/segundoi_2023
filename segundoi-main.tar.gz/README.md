# segundoi
Propor idéias para a resolução de problemas para calvice. Desde estágios iniciantes à avançados.
Indicação de produtos para tratamento e práticas para a diminuição da causa.

